CREATE TRIGGER `verifica_sito_prodotto` BEFORE INSERT ON `dettagli_del_carrello`
 FOR EACH ROW BEGIN
    DECLARE sito_account VARCHAR(30);
    DECLARE sito_prodotto VARCHAR(30);

    SELECT Sito.URL INTO sito_account
    FROM Carrello
    JOIN Account ON Carrello.`E-mail` = Account.`E-mail`
    JOIN Sito ON Account.URL = Sito.URL
    WHERE Carrello.ID_Carrello = NEW.ID_Carrello;

    SELECT URL INTO sito_prodotto
    FROM disponibilità
    WHERE ID_Prodotto = NEW.ID_Prodotto;

    IF sito_prodotto <> sito_account THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Impossibile inserire il prodotto nel carrello: il prodotto è su un sito diverso dal sito dell''account associato al carrello.';
    END IF;
END