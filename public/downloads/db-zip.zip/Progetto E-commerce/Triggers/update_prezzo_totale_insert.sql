CREATE TRIGGER `update_prezzo_totale_insert` AFTER INSERT ON `dettagli_del_carrello`
 FOR EACH ROW BEGIN
    DECLARE nuovo_prezzo_totale FLOAT;

    SELECT SUM(Prezzo_parziale)
    INTO nuovo_prezzo_totale
    FROM Dettagli_del_carrello
    WHERE ID_Carrello = NEW.ID_Carrello;

    UPDATE Carrello
    SET Prezzo_totale = nuovo_prezzo_totale
    WHERE ID_Carrello = NEW.ID_Carrello;
END