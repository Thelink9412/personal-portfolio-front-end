CREATE TRIGGER `Prezzo_prodotto` BEFORE INSERT ON `prodotto`
 FOR EACH ROW IF NEW.Prezzo < 0 THEN
    	SET NEW.Prezzo = 0;
    END IF