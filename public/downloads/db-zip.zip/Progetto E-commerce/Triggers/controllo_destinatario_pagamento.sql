CREATE TRIGGER `controllo_destinatario_pagamento` BEFORE INSERT ON `pagamento`
 FOR EACH ROW BEGIN
    DECLARE destinatario_valido VARCHAR(30);
    
    SELECT p.IBAN
    INTO destinatario_valido
    FROM Account a
    JOIN Sito s ON a.URL = s.URL
    JOIN proprietario p ON s.ID_Proprietario = p.ID_Proprietario
    WHERE a.IBAN = NEW.Pagante AND p.IBAN = NEW.Destinatario;

    IF destinatario_valido IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Il destinatario del pagamento non è il proprietario del sito associato all''account del pagante';
    END IF;
END