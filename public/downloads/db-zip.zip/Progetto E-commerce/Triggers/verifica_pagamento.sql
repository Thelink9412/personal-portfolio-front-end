CREATE TRIGGER `verifica_pagamento` BEFORE INSERT ON `pagamento`
 FOR EACH ROW BEGIN
    DECLARE saldo_account FLOAT;
    DECLARE prezzo_totale_carrello FLOAT;
    DECLARE indirizzo_spedizione VARCHAR(50);

    SELECT Saldo INTO saldo_account
    FROM Account
    WHERE IBAN = NEW.Pagante;

    SELECT Prezzo_totale INTO prezzo_totale_carrello
    FROM Carrello
    WHERE ID_Carrello = NEW.ID_Carrello;
   
    SELECT Indirizzo_di_spedizione INTO indirizzo_spedizione
    FROM Account
    WHERE IBAN = NEW.Pagante;
    
    IF saldo_account < prezzo_totale_carrello THEN
        SET NEW.Esito = 0;
        SET NEW.Importo = prezzo_totale_carrello;
     ELSE 
        SET NEW.Esito = 1;
        SET NEW.Importo = prezzo_totale_carrello;
        
        INSERT INTO Ordine (ID_Carrello, `E-mail`, Indirizzo_di_spedizione, Data, Prezzo, Stato)
        VALUES (NEW.ID_Carrello, (SELECT `E-mail` FROM Account WHERE IBAN = NEW.Pagante), indirizzo_spedizione, NOW(), prezzo_totale_carrello, 'pronto per la spedizione');
        
        UPDATE Disponibilità d
        JOIN Dettagli_del_carrello dc ON d.ID_Prodotto = dc.ID_Prodotto
        SET d.`Quantità` = d.`Quantità` - dc.`Quantità`
        WHERE dc.ID_Carrello = NEW.ID_Carrello;
        
        UPDATE Account SET Saldo = saldo_account - prezzo_totale_carrello WHERE IBAN = NEW.Pagante;
                
    END IF;
END