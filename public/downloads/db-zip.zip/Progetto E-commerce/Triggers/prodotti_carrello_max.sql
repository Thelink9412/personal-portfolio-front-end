CREATE TRIGGER `prodotti_carrello_max` BEFORE INSERT ON `dettagli_del_carrello`
 FOR EACH ROW BEGIN
    DECLARE product_count INT;

    SELECT COUNT(DISTINCT ID_Prodotto) INTO product_count
    FROM Dettagli_del_carrello
    WHERE ID_Carrello = NEW.ID_Carrello;

    IF product_count >= 5 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Il carrello non può contenere più di 5 prodotti diversi.';
    END IF;
END