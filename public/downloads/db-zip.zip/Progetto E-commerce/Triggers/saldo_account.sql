CREATE TRIGGER `Saldo_account` BEFORE INSERT ON `account`
 FOR EACH ROW IF NEW.Saldo < 0 THEN
    	SET NEW.Saldo = 0;
    END IF