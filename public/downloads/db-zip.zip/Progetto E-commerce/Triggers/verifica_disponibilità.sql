CREATE TRIGGER `verifica_disponibilità` BEFORE INSERT ON `dettagli_del_carrello`
 FOR EACH ROW BEGIN
    DECLARE quantita_disponibile INT;

    SELECT Quantità INTO quantita_disponibile
    FROM Disponibilità
    WHERE ID_Prodotto = NEW.ID_Prodotto;
       
    IF quantita_disponibile <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Il prodotto non è disponibile nel carrello';
    END IF;
END