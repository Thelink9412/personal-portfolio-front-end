CREATE TRIGGER `calcola_prezzo_parziale` BEFORE INSERT ON `dettagli_del_carrello`
 FOR EACH ROW BEGIN
    DECLARE prezzo_prodotto FLOAT;

    SELECT Prezzo INTO prezzo_prodotto
    FROM Prodotto
    WHERE ID_Prodotto = NEW.ID_Prodotto;

    SET NEW.Prezzo_parziale = prezzo_prodotto * NEW.`Quantità`;
END