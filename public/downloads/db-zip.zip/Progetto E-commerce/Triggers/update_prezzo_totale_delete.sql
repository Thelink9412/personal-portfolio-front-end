CREATE TRIGGER `update_prezzo_totale_delete` BEFORE DELETE ON `dettagli_del_carrello`
 FOR EACH ROW BEGIN
    DECLARE prezzo_vecchio FLOAT;
    
    SELECT Prezzo_parziale INTO prezzo_vecchio
    FROM dettagli_del_carrello
    WHERE ID_Carrello = OLD.ID_Carrello
    AND ID_Prodotto = OLD.ID_Prodotto;

    UPDATE Carrello
    SET Prezzo_totale = Prezzo_totale - prezzo_vecchio
    WHERE ID_Carrello = OLD.ID_Carrello;
END