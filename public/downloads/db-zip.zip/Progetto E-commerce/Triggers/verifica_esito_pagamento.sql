CREATE TRIGGER `verifica_esito_pagamento` BEFORE INSERT ON `pagamento`
 FOR EACH ROW BEGIN
    DECLARE esiti INT;

    SELECT COUNT(*) INTO esiti
    FROM Pagamento
    WHERE ID_Carrello = NEW.ID_Carrello AND Esito = 1;

    IF esiti > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Non � possibile inserire un nuovo pagamento per lo stesso carrello con esito positivo.';
    END IF;
END