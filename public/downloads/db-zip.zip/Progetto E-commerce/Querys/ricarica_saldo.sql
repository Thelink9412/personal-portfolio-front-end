UPDATE Account
SET Saldo = Saldo + 200
WHERE E-mail = 'franci.b@libero.it';