SELECT COUNT(*) AS Numero_Account
FROM Account
WHERE URL = 'www.megamarketstore.com';
