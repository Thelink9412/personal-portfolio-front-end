SELECT Saldo
FROM account
WHERE `E-mail` = 'franci.b@libero.it';