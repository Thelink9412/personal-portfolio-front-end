SELECT dc.ID_Prodotto, p.Nome, p.Descrizione, dc.Quantità, dc.Prezzo_parziale
FROM Dettagli_del_carrello dc
JOIN Prodotto p ON dc.ID_Prodotto = p.ID_Prodotto
WHERE dc.ID_Carrello = 1;