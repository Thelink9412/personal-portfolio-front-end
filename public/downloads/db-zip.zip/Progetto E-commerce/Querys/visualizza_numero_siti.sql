SELECT COUNT(DISTINCT URL) AS Numero_Siti
FROM Disponibilità
WHERE ID_Prodotto = 1;