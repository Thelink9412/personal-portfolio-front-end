SELECT Stato
FROM Ordine
WHERE ID_Carrello = 1;