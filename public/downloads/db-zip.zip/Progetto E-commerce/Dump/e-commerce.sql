-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Feb 28, 2024 alle 22:05
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-commerce`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `E-mail` varchar(20) NOT NULL,
  `URL` varchar(30) NOT NULL,
  `IBAN` varchar(30) NOT NULL,
  `Nome_utente` varchar(20) NOT NULL,
  `Indirizzo_di_spedizione` varchar(50) NOT NULL,
  `Saldo` float NOT NULL,
  `CF` varchar(30) NOT NULL,
  PRIMARY KEY (`E-mail`,`URL`,`IBAN`),
  KEY `URL_account` (`URL`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

--
-- Dump dei dati per la tabella `account`
--

INSERT INTO `account` (`E-mail`, `URL`, `IBAN`, `Nome_utente`, `Indirizzo_di_spedizione`, `Saldo`, `CF`) VALUES
('franci.b@libero.it', 'www.smartbuyoutlet.net', 'IT90OUTLET789012345678', 'francesca_bruni', 'Via Venezia 70, Milano', 400, 'BRNFCB85A41H501U'),
('giovi.b@gmail.com', 'www.supershoponline.it', 'IT56ONLINE123456789012', 'giovanni_bianchi', 'Via Arcirù 36, Troina', 150, 'BNCGNN80A20H501C'),
('giuseppe.b@gmail.com', 'www.smartbuyoutlet.net', 'IT34SMART789012345678', 'giuseppe_bianchi', 'Via Posterna 20, Troina', 285.13, 'BNCPPA85A41H501Z'),
('laura.v@libero.it', 'www.supershoponline.it', 'IT34SHOP123456789012', 'laura_verdi', 'Via Gabriele D\'Annunzio 2, Catania', 500, 'VRDLRA75A41H712B'),
('luigi.v@gmail.com', 'www.megamarketstore.com', 'IT78MEGA567890123456', 'luigi_verdi', 'Via Garibaldi 33, Domodossola', 450, 'VRDLGI80A41H501G'),
('marco.g@hotmail.com', 'www.megamarketstore.com', 'IT34MEGA567890123456', 'marco_gialli', 'Via Alessandro Manzoni 9, Catania', 990.01, 'GLLMRC80A01H501E'),
('mario.r@gmail.com', 'www.supershoponline.it', 'IT12SUPER123456789012', 'mario_rossi', 'Via Ugo Giuffrida 42, Troina', 300, 'RSSMRA80A01H501A'),
('paola.r@hotmail.it', 'www.smartbuyoutlet.net', 'IT56OUTLET789012345678', 'paola_rossi', 'Via Luigi Pirandello 7, Firenze', 490.03, 'RSSPPA85A41H501W'),
('sara.neri@gmail.com', 'www.megamarketstore.com', 'IT56STORE567890123456', 'sara_neri', 'Via Dante Alighieri 41, Roma', 1140.04, 'NERSRA75A41H501F');

--
-- Trigger `account`
--
DELIMITER $$
CREATE TRIGGER `Saldo_account` BEFORE INSERT ON `account` FOR EACH ROW IF NEW.Saldo < 0 THEN
    	SET NEW.Saldo = 0;
    END IF
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struttura della tabella `carrello`
--

CREATE TABLE IF NOT EXISTS `carrello` (
  `ID_Carrello` int(3) NOT NULL,
  `Prezzo_totale` float NOT NULL DEFAULT 0,
  `E-mail` varchar(20) NOT NULL,
  PRIMARY KEY (`ID_Carrello`),
  KEY `E-mail_carrello` (`E-mail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

--
-- Dump dei dati per la tabella `carrello`
--

INSERT INTO `carrello` (`ID_Carrello`, `Prezzo_totale`, `E-mail`) VALUES
(1, 1299.99, 'laura.v@libero.it'),
(2, 9.99, 'marco.g@hotmail.com'),
(3, 109.97, 'paola.r@hotmail.it'),
(4, 59.97, 'sara.neri@gmail.com'),
(5, 39.98, 'giuseppe.b@gmail.com'),
(6, 119.97, 'luigi.v@gmail.com');

-- --------------------------------------------------------

--
-- Struttura della tabella `dettagli_del_carrello`
--

CREATE TABLE IF NOT EXISTS `dettagli_del_carrello` (
  `ID_Carrello` int(3) NOT NULL,
  `Prezzo_parziale` float NOT NULL DEFAULT 0,
  `Quantità` int(3) NOT NULL,
  `ID_Prodotto` int(3) NOT NULL,
  PRIMARY KEY (`ID_Prodotto`,`ID_Carrello`),
  KEY `ID_Carrello_dettagli` (`ID_Carrello`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

--
-- Dump dei dati per la tabella `dettagli_del_carrello`
--

INSERT INTO `dettagli_del_carrello` (`ID_Carrello`, `Prezzo_parziale`, `Quantità`, `ID_Prodotto`) VALUES
(1, 1299.99, 1, 2),
(2, 9.99, 1, 7),
(6, 19.98, 2, 7),
(6, 99.99, 1, 9),
(4, 59.97, 3, 10),
(3, 79.99, 1, 12),
(5, 39.98, 2, 13),
(3, 29.98, 2, 15);

--
-- Trigger `dettagli_del_carrello`
--
DELIMITER $$
CREATE TRIGGER `calcola_prezzo_parziale` BEFORE INSERT ON `dettagli_del_carrello` FOR EACH ROW BEGIN
    DECLARE prezzo_prodotto FLOAT;

    SELECT Prezzo INTO prezzo_prodotto
    FROM Prodotto
    WHERE ID_Prodotto = NEW.ID_Prodotto;

    SET NEW.Prezzo_parziale = prezzo_prodotto * NEW.`Quantità`;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `prodotti_carrello_max` BEFORE INSERT ON `dettagli_del_carrello` FOR EACH ROW BEGIN
    DECLARE product_count INT;

    SELECT COUNT(DISTINCT ID_Prodotto) INTO product_count
    FROM Dettagli_del_carrello
    WHERE ID_Carrello = NEW.ID_Carrello;

    IF product_count >= 5 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Il carrello non può contenere più di 5 prodotti diversi.';
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_prezzo_totale_delete` BEFORE DELETE ON `dettagli_del_carrello` FOR EACH ROW BEGIN
    DECLARE prezzo_vecchio FLOAT;
    
    SELECT Prezzo_parziale INTO prezzo_vecchio
    FROM dettagli_del_carrello
    WHERE ID_Carrello = OLD.ID_Carrello
    AND ID_Prodotto = OLD.ID_Prodotto;

    UPDATE Carrello
    SET Prezzo_totale = Prezzo_totale - prezzo_vecchio
    WHERE ID_Carrello = OLD.ID_Carrello;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_prezzo_totale_insert` AFTER INSERT ON `dettagli_del_carrello` FOR EACH ROW BEGIN
    DECLARE nuovo_prezzo_totale FLOAT;

    SELECT SUM(Prezzo_parziale)
    INTO nuovo_prezzo_totale
    FROM Dettagli_del_carrello
    WHERE ID_Carrello = NEW.ID_Carrello;

    UPDATE Carrello
    SET Prezzo_totale = nuovo_prezzo_totale
    WHERE ID_Carrello = NEW.ID_Carrello;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `verifica_disponibilità` BEFORE INSERT ON `dettagli_del_carrello` FOR EACH ROW BEGIN
    DECLARE quantita_disponibile INT;

    SELECT Quantità INTO quantita_disponibile
    FROM Disponibilità
    WHERE ID_Prodotto = NEW.ID_Prodotto;
       
    IF quantita_disponibile <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Il prodotto non è disponibile nel carrello';
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `verifica_sito_prodotto` BEFORE INSERT ON `dettagli_del_carrello` FOR EACH ROW BEGIN
    DECLARE sito_account VARCHAR(30);
    DECLARE sito_prodotto VARCHAR(30);

    SELECT Sito.URL INTO sito_account
    FROM Carrello
    JOIN Account ON Carrello.`E-mail` = Account.`E-mail`
    JOIN Sito ON Account.URL = Sito.URL
    WHERE Carrello.ID_Carrello = NEW.ID_Carrello;

    SELECT URL INTO sito_prodotto
    FROM disponibilità
    WHERE ID_Prodotto = NEW.ID_Prodotto;

    IF sito_prodotto <> sito_account THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Impossibile inserire il prodotto nel carrello: il prodotto è su un sito diverso dal sito dell''account associato al carrello.';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struttura della tabella `disponibilità`
--

CREATE TABLE IF NOT EXISTS `disponibilità` (
  `URL` varchar(30) NOT NULL,
  `ID_Prodotto` int(3) NOT NULL,
  `Quantità` int(4) NOT NULL,
  PRIMARY KEY (`URL`,`ID_Prodotto`),
  KEY `ID_Prodotto_disponibilità` (`ID_Prodotto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

--
-- Dump dei dati per la tabella `disponibilità`
--

INSERT INTO `disponibilità` (`URL`, `ID_Prodotto`, `Quantità`) VALUES
('www.megamarketstore.com', 6, 200),
('www.megamarketstore.com', 7, 99),
('www.megamarketstore.com', 8, 500),
('www.megamarketstore.com', 9, 149),
('www.megamarketstore.com', 10, 47),
('www.smartbuyoutlet.net', 11, 300),
('www.smartbuyoutlet.net', 12, 99),
('www.smartbuyoutlet.net', 13, 98),
('www.smartbuyoutlet.net', 14, 300),
('www.smartbuyoutlet.net', 15, 1995),
('www.supershoponline.it', 1, 200),
('www.supershoponline.it', 2, 200),
('www.supershoponline.it', 3, 1000),
('www.supershoponline.it', 4, 300),
('www.supershoponline.it', 5, 900);

-- --------------------------------------------------------

--
-- Struttura della tabella `ordine`
--

CREATE TABLE IF NOT EXISTS `ordine` (
  `ID_Carrello` int(3) NOT NULL,
  `E-mail` varchar(20) NOT NULL,
  `Indirizzo_di_spedizione` varchar(50) NOT NULL,
  `Data` datetime NOT NULL,
  `Prezzo` float NOT NULL,
  `Stato` varchar(30) NOT NULL,
  PRIMARY KEY (`ID_Carrello`),
  KEY `E-mail_ordine` (`E-mail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

--
-- Dump dei dati per la tabella `ordine`
--

INSERT INTO `ordine` (`ID_Carrello`, `E-mail`, `Indirizzo_di_spedizione`, `Data`, `Prezzo`, `Stato`) VALUES
(2, 'marco.g@hotmail.com', 'Via Alessandro Manzoni 9, Catania', '2024-02-21 12:41:26', 9.99, 'pronto per la spedizione'),
(3, 'paola.r@hotmail.it', 'Via Luigi Pirandello 7, Firenze', '2024-02-19 17:17:03', 109.97, 'in consegna'),
(4, 'sara.neri@gmail.com', 'Via Dante Alighieri 41, Roma', '2024-02-21 12:39:11', 59.97, 'pronto per la spedizione');

-- --------------------------------------------------------

--
-- Struttura della tabella `pagamento`
--

CREATE TABLE IF NOT EXISTS `pagamento` (
  `ID_Carrello` int(3) NOT NULL,
  `Data` datetime NOT NULL,
  `Esito` tinyint(1) NOT NULL DEFAULT 0,
  `Metodo_di_pagamento` varchar(20) NOT NULL,
  `Pagante` varchar(30) NOT NULL,
  `Destinatario` varchar(30) NOT NULL,
  `Importo` float NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID_Carrello`,`Data`,`Esito`),
  KEY `Pagante` (`Pagante`) USING BTREE,
  KEY `Destinatario` (`Destinatario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

--
-- Dump dei dati per la tabella `pagamento`
--

INSERT INTO `pagamento` (`ID_Carrello`, `Data`, `Esito`, `Metodo_di_pagamento`, `Pagante`, `Destinatario`, `Importo`) VALUES
(1, '2024-02-13 11:58:37', 0, 'Carta di credito', 'IT34SHOP123456789012', 'IT90UVWXY8901234567890123456', 938.98),
(1, '2024-02-15 12:04:02', 0, 'Carta di credito', 'IT34SHOP123456789012', 'IT90UVWXY8901234567890123456', 938.98),
(2, '2024-02-21 12:40:37', 1, 'Accredito bancario', 'IT34MEGA567890123456', 'IT34FGHIJ5678901234567890123', 9.99),
(3, '2024-02-19 17:15:30', 1, 'Carta di credito', 'IT56OUTLET789012345678', 'IT56KLMNO6789012345678901234', 109.97),
(4, '2024-02-21 12:38:30', 1, 'Carta di credito', 'IT56STORE567890123456', 'IT34FGHIJ5678901234567890123', 59.97);

--
-- Trigger `pagamento`
--
DELIMITER $$
CREATE TRIGGER `controllo_destinatario_pagamento` BEFORE INSERT ON `pagamento` FOR EACH ROW BEGIN
    DECLARE destinatario_valido VARCHAR(30);
    
    SELECT p.IBAN
    INTO destinatario_valido
    FROM Account a
    JOIN Sito s ON a.URL = s.URL
    JOIN proprietario p ON s.ID_Proprietario = p.ID_Proprietario
    WHERE a.IBAN = NEW.Pagante AND p.IBAN = NEW.Destinatario;

    IF destinatario_valido IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Il destinatario del pagamento non è il proprietario del sito associato all''account del pagante';
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `verifica_esito_pagamento` BEFORE INSERT ON `pagamento` FOR EACH ROW BEGIN
    DECLARE esiti INT;

    SELECT COUNT(*) INTO esiti
    FROM Pagamento
    WHERE ID_Carrello = NEW.ID_Carrello AND Esito = 1;

    IF esiti > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Non è possibile inserire un nuovo pagamento per lo stesso carrello con esito positivo.';
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `verifica_pagamento` BEFORE INSERT ON `pagamento` FOR EACH ROW BEGIN
    DECLARE saldo_account FLOAT;
    DECLARE prezzo_totale_carrello FLOAT;
    DECLARE indirizzo_spedizione VARCHAR(50);

    SELECT Saldo INTO saldo_account
    FROM Account
    WHERE IBAN = NEW.Pagante;

    SELECT Prezzo_totale INTO prezzo_totale_carrello
    FROM Carrello
    WHERE ID_Carrello = NEW.ID_Carrello;
   
    SELECT Indirizzo_di_spedizione INTO indirizzo_spedizione
    FROM Account
    WHERE IBAN = NEW.Pagante;
    
    IF saldo_account < prezzo_totale_carrello THEN
        SET NEW.Esito = 0;
        SET NEW.Importo = prezzo_totale_carrello;
     ELSE 
        SET NEW.Esito = 1;
        SET NEW.Importo = prezzo_totale_carrello;
        
        INSERT INTO Ordine (ID_Carrello, `E-mail`, Indirizzo_di_spedizione, Data, Prezzo, Stato)
        VALUES (NEW.ID_Carrello, (SELECT `E-mail` FROM Account WHERE IBAN = NEW.Pagante), indirizzo_spedizione, NOW(), prezzo_totale_carrello, 'pronto per la spedizione');
        
        UPDATE Disponibilità d
        JOIN Dettagli_del_carrello dc ON d.ID_Prodotto = dc.ID_Prodotto
        SET d.`Quantità` = d.`Quantità` - dc.`Quantità`
        WHERE dc.ID_Carrello = NEW.ID_Carrello;
        
        UPDATE Account SET Saldo = saldo_account - prezzo_totale_carrello WHERE IBAN = NEW.Pagante;
                
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struttura della tabella `prodotto`
--

CREATE TABLE IF NOT EXISTS `prodotto` (
  `ID_Prodotto` int(3) NOT NULL AUTO_INCREMENT,
  `Categoria` varchar(20) NOT NULL,
  `Nome` varchar(20) NOT NULL,
  `Descrizione` varchar(200) NOT NULL,
  `Prezzo` float NOT NULL,
  PRIMARY KEY (`ID_Prodotto`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

--
-- Dump dei dati per la tabella `prodotto`
--

INSERT INTO `prodotto` (`ID_Prodotto`, `Categoria`, `Nome`, `Descrizione`, `Prezzo`) VALUES
(1, 'Elettronica', 'Smartphone Galaxy S2', 'Telefono di ultima generazione con fotocamera avanzata', 899.99),
(2, 'Elettronica', 'Laptop UltraBook X1', 'Portatile leggero e potente per professionisti in movimento', 1299.99),
(3, 'Abbigliamento', 'Scarpe da Corsa Air ', 'Scarpe sportive con ammortizzazione avanzata per prestazioni ottimali', 129.99),
(4, 'Elettronica', 'Tastiera Wireless ', 'Tastiera ergonomica con connessione senza fili per una maggiore comodità', 49.99),
(5, 'Accessori', 'Borsa a Tracolla', 'Borsa resistente e versatile per trasportare comodamente i tuoi oggetti quotidiani', 39.99),
(6, 'Elettronica', 'Televisore LED 4K', 'TV ad alta definizione con funzionalità Smart integrate per un\'esperienza di visione avanzata', 799.99),
(7, 'Alimentari', 'Caffè Espresso Ita', 'Miscela di caffè pregiato per un aroma intenso e un gusto ricco, Categoria: Alimentari', 9.99),
(8, 'Abbigliamento', 'Giacca in Pelle ', 'Giacca di pelle di alta qualità con design classico e dettagli eleganti', 199.99),
(9, 'Cucina', 'Set Pentole Inox', 'Pentole resistenti e durevoli per una cottura precisa e uniforme', 99.99),
(10, 'Bellezza', 'Profumo Blue Ocean', 'Fragranza fresca e vibrante con note marine per l\'uomo moderno', 19.99),
(11, 'Elettronica', 'Smart Fitness Clock', 'Orologio multifunzione con monitoraggio del fitness e notifiche intelligenti', 119.99),
(12, 'Accessori', 'Valigia Rigida', 'Valigia resistente con ruote multidirezionali per un facile trasporto durante i viaggi', 79.99),
(13, 'Bellezza', 'Pennelli Trucco', 'Pennelli morbidi e di alta qualità per una perfetta applicazione del trucco', 19.99),
(14, 'Elettronica', 'Cassa Bluetooth', 'Altoparlante compatto con connessione wireless per un\'esperienza musicale senza fili', 39.99),
(15, 'Abbigliamento', 'T-shirt in Cotone', 'Maglietta casual con stampa trendy per uno stile moderno e confortevole', 14.99);

--
-- Trigger `prodotto`
--
DELIMITER $$
CREATE TRIGGER `Prezzo_prodotto` BEFORE INSERT ON `prodotto` FOR EACH ROW IF NEW.Prezzo < 0 THEN
    	SET NEW.Prezzo = 0;
    END IF
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struttura della tabella `proprietario`
--

CREATE TABLE IF NOT EXISTS `proprietario` (
  `ID_Proprietario` int(3) NOT NULL AUTO_INCREMENT,
  `IBAN` varchar(40) NOT NULL,
  `Nome` varchar(20) NOT NULL,
  `Descrizione` varchar(400) NOT NULL,
  `Indirizzo_sede` varchar(60) NOT NULL,
  PRIMARY KEY (`ID_Proprietario`,`IBAN`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

--
-- Dump dei dati per la tabella `proprietario`
--

INSERT INTO `proprietario` (`ID_Proprietario`, `IBAN`, `Nome`, `Descrizione`, `Indirizzo_sede`) VALUES
(1, 'IT90UVWXY8901234567890123456', 'SuperTech Srl', 'SuperTech Srl: leader nel settore dell\'elettronica, offriamo una vasta gamma di prodotti innovativi e tecnologici per soddisfare ogni esigenza. La nostra mission è fornire ai nostri clienti soluzioni all\'avanguardia e un servizio clienti eccellente.', 'Via Alessandro Manzoni 15, Milano'),
(2, 'IT34FGHIJ5678901234567890123', 'MegaMarket Spa', 'MegaMarket Spa: punto di riferimento per lo shopping online, ci impegniamo a offrire una selezione di prodotti di alta qualità a prezzi competitivi. La nostra visione è creare un\'esperienza di shopping online conveniente e piacevole per tutti i nostri clienti.', 'Via Giacomo Leopardi 44, Roma'),
(3, 'IT56KLMNO6789012345678901234', 'SmartBuy Solutions', 'SmartBuy Solutions: forniamo soluzioni intelligenti per gli acquisti online, offrendo una vasta gamma di prodotti di alta qualità a prezzi convenienti. La nostra missione è rendere lo shopping online semplice, conveniente e gratificante per tutti i nostri clienti.', 'Via Nazionale 61, Torino');

-- --------------------------------------------------------

--
-- Struttura della tabella `sito`
--

CREATE TABLE IF NOT EXISTS `sito` (
  `URL` varchar(30) NOT NULL,
  `ID_Proprietario` int(3) NOT NULL,
  `Nome` varchar(20) NOT NULL,
  `Descrizione` varchar(400) NOT NULL,
  PRIMARY KEY (`URL`,`ID_Proprietario`),
  KEY `ID_Proprietario_sito` (`ID_Proprietario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

--
-- Dump dei dati per la tabella `sito`
--

INSERT INTO `sito` (`URL`, `ID_Proprietario`, `Nome`, `Descrizione`) VALUES
('www.megamarketstore.com', 2, 'Mega Market Store', 'Mega Market, il tuo punto di riferimento per gli acquisti online! Scopri una vasta selezione di prodotti di qualità a prezzi convenienti. Approfitta delle offerte esclusive e vivi un\'esperienza di shopping senza pari!'),
('www.smartbuyoutlet.net', 3, 'Smart Buy Outlet', 'Smart Buy Outlet: il posto perfetto per trovare i migliori affari online! Esplora la nostra selezione di prodotti di tendenza a prezzi convenienti. Approfitta delle offerte esclusive e risparmia sui tuoi acquisti su Smart Buy Outlet!'),
('www.supershoponline.it', 1, 'Super Shop Online', 'Super Shop offre una vasta gamma di prodotti di alta qualità, dall\'elettronica all\'abbigliamento, per soddisfare ogni esigenza dei suoi clienti. Scopri le offerte esclusive e vivi un\'esperienza di shopping senza pari con Super Shop!');

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `URL_account` FOREIGN KEY (`URL`) REFERENCES `sito` (`URL`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `carrello`
--
ALTER TABLE `carrello`
  ADD CONSTRAINT `E-mail_carrello` FOREIGN KEY (`E-mail`) REFERENCES `account` (`E-mail`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `dettagli_del_carrello`
--
ALTER TABLE `dettagli_del_carrello`
  ADD CONSTRAINT `ID_Carrello_dettagli` FOREIGN KEY (`ID_Carrello`) REFERENCES `carrello` (`ID_Carrello`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ID_Prodotto_dettagli` FOREIGN KEY (`ID_Prodotto`) REFERENCES `prodotto` (`ID_Prodotto`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `disponibilità`
--
ALTER TABLE `disponibilità`
  ADD CONSTRAINT `ID_Prodotto_disponibilità` FOREIGN KEY (`ID_Prodotto`) REFERENCES `prodotto` (`ID_Prodotto`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `URL_disponibilità` FOREIGN KEY (`URL`) REFERENCES `sito` (`URL`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `ordine`
--
ALTER TABLE `ordine`
  ADD CONSTRAINT `E-mail_ordine` FOREIGN KEY (`E-mail`) REFERENCES `account` (`E-mail`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `ID_Carrello_ordine` FOREIGN KEY (`ID_Carrello`) REFERENCES `carrello` (`ID_Carrello`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limiti per la tabella `pagamento`
--
ALTER TABLE `pagamento`
  ADD CONSTRAINT `ID_Carrello_pagamento` FOREIGN KEY (`ID_Carrello`) REFERENCES `carrello` (`ID_Carrello`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `sito`
--
ALTER TABLE `sito`
  ADD CONSTRAINT `ID_Proprietario_sito` FOREIGN KEY (`ID_Proprietario`) REFERENCES `proprietario` (`ID_Proprietario`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
