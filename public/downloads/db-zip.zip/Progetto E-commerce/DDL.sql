-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Feb 24, 2024 alle 15:36
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-commerce`
--
CREATE DATABASE IF NOT EXISTS `e-commerce` DEFAULT CHARACTER SET latin1 COLLATE latin1_general_cs;
USE `e-commerce`;

-- --------------------------------------------------------

--
-- Struttura della tabella `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `E-mail` varchar(20) NOT NULL,
  `URL` varchar(30) NOT NULL,
  `IBAN` varchar(30) NOT NULL,
  `Nome_utente` varchar(20) NOT NULL,
  `Indirizzo_di_spedizione` varchar(50) NOT NULL,
  `Saldo` float NOT NULL,
  `CF` varchar(30) NOT NULL,
  PRIMARY KEY (`E-mail`,`URL`,`IBAN`),
  KEY `URL_account` (`URL`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

-- --------------------------------------------------------

--
-- Struttura della tabella `carrello`
--

CREATE TABLE IF NOT EXISTS `carrello` (
  `ID_Carrello` int(3) NOT NULL,
  `Prezzo_totale` float NOT NULL DEFAULT 0,
  `E-mail` varchar(20) NOT NULL,
  PRIMARY KEY (`ID_Carrello`),
  KEY `E-mail_carrello` (`E-mail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

-- --------------------------------------------------------

--
-- Struttura della tabella `dettagli_del_carrello`
--

CREATE TABLE IF NOT EXISTS `dettagli_del_carrello` (
  `ID_Carrello` int(3) NOT NULL,
  `Prezzo_parziale` float NOT NULL DEFAULT 0,
  `Quantità` int(3) NOT NULL,
  `ID_Prodotto` int(3) NOT NULL,
  PRIMARY KEY (`ID_Prodotto`,`ID_Carrello`),
  KEY `ID_Carrello_dettagli` (`ID_Carrello`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

-- --------------------------------------------------------

--
-- Struttura della tabella `disponibilità`
--

CREATE TABLE IF NOT EXISTS `disponibilità` (
  `URL` varchar(30) NOT NULL,
  `ID_Prodotto` int(3) NOT NULL,
  `Quantità` int(4) NOT NULL,
  PRIMARY KEY (`URL`,`ID_Prodotto`),
  KEY `ID_Prodotto_disponibilità` (`ID_Prodotto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

-- --------------------------------------------------------

--
-- Struttura della tabella `ordine`
--

CREATE TABLE IF NOT EXISTS `ordine` (
  `ID_Carrello` int(3) NOT NULL,
  `E-mail` varchar(20) NOT NULL,
  `Indirizzo_di_spedizione` varchar(50) NOT NULL,
  `Data` datetime NOT NULL,
  `Prezzo` float NOT NULL,
  `Stato` varchar(30) NOT NULL,
  PRIMARY KEY (`ID_Carrello`),
  KEY `E-mail_ordine` (`E-mail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

-- --------------------------------------------------------

--
-- Struttura della tabella `pagamento`
--

CREATE TABLE IF NOT EXISTS `pagamento` (
  `ID_Carrello` int(3) NOT NULL,
  `Data` datetime NOT NULL,
  `Esito` tinyint(1) NOT NULL DEFAULT 0,
  `Metodo_di_pagamento` varchar(20) NOT NULL,
  `Pagante` varchar(30) NOT NULL,
  `Destinatario` varchar(30) NOT NULL,
  `Importo` float NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID_Carrello`,`Data`,`Esito`),
  KEY `Pagante` (`Pagante`) USING BTREE,
  KEY `Destinatario` (`Destinatario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

-- --------------------------------------------------------

--
-- Struttura della tabella `prodotto`
--

CREATE TABLE IF NOT EXISTS `prodotto` (
  `ID_Prodotto` int(3) NOT NULL AUTO_INCREMENT,
  `Categoria` varchar(20) NOT NULL,
  `Nome` varchar(20) NOT NULL,
  `Descrizione` varchar(200) NOT NULL,
  `Prezzo` float NOT NULL,
  PRIMARY KEY (`ID_Prodotto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

-- --------------------------------------------------------

--
-- Struttura della tabella `proprietario`
--

CREATE TABLE IF NOT EXISTS `proprietario` (
  `ID_Proprietario` int(3) NOT NULL AUTO_INCREMENT,
  `IBAN` varchar(40) NOT NULL,
  `Nome` varchar(20) NOT NULL,
  `Descrizione` varchar(400) NOT NULL,
  `Indirizzo_sede` varchar(60) NOT NULL,
  PRIMARY KEY (`ID_Proprietario`,`IBAN`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

-- --------------------------------------------------------

--
-- Struttura della tabella `sito`
--

CREATE TABLE IF NOT EXISTS `sito` (
  `URL` varchar(30) NOT NULL,
  `ID_Proprietario` int(3) NOT NULL,
  `Nome` varchar(20) NOT NULL,
  `Descrizione` varchar(400) NOT NULL,
  PRIMARY KEY (`URL`,`ID_Proprietario`),
  KEY `ID_Proprietario_sito` (`ID_Proprietario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `URL_account` FOREIGN KEY (`URL`) REFERENCES `sito` (`URL`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `carrello`
--
ALTER TABLE `carrello`
  ADD CONSTRAINT `E-mail_carrello` FOREIGN KEY (`E-mail`) REFERENCES `account` (`E-mail`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `dettagli_del_carrello`
--
ALTER TABLE `dettagli_del_carrello`
  ADD CONSTRAINT `ID_Carrello_dettagli` FOREIGN KEY (`ID_Carrello`) REFERENCES `carrello` (`ID_Carrello`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ID_Prodotto_dettagli` FOREIGN KEY (`ID_Prodotto`) REFERENCES `prodotto` (`ID_Prodotto`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `disponibilità`
--
ALTER TABLE `disponibilità`
  ADD CONSTRAINT `ID_Prodotto_disponibilità` FOREIGN KEY (`ID_Prodotto`) REFERENCES `prodotto` (`ID_Prodotto`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `URL_disponibilità` FOREIGN KEY (`URL`) REFERENCES `sito` (`URL`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `ordine`
--
ALTER TABLE `ordine`
  ADD CONSTRAINT `E-mail_ordine` FOREIGN KEY (`E-mail`) REFERENCES `account` (`E-mail`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `ID_Carrello_ordine` FOREIGN KEY (`ID_Carrello`) REFERENCES `carrello` (`ID_Carrello`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limiti per la tabella `pagamento`
--
ALTER TABLE `pagamento`
  ADD CONSTRAINT `ID_Carrello_pagamento` FOREIGN KEY (`ID_Carrello`) REFERENCES `carrello` (`ID_Carrello`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limiti per la tabella `sito`
--
ALTER TABLE `sito`
  ADD CONSTRAINT `ID_Proprietario_sito` FOREIGN KEY (`ID_Proprietario`) REFERENCES `proprietario` (`ID_Proprietario`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
